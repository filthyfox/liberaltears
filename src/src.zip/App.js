import React, { Component } from 'react';
import './App.css';
import questionsList from './QuestionsList/QuestionsList';

import Question from './Question/Question';

class App extends Component {

	state = {
		isTestStarted: false,
		isTestFinished: false,
		currentStep: 1,
		questionsList: questionsList,
	}


	switchStepNext = () => {

		if( this.state.currentStep < this.state.questionsList.length ){
			var nextStep = this.state.currentStep + 1;
			this.setState({
				currentStep: nextStep
			})
		} else {
			alert('IT WAS THE LAST QUSTION')
		}
		
	}


	render() {

		const questionsOutput = this.state.questionsList.map(theQuestion => {
			let isCurrent = false;
			if( theQuestion.id === this.state.currentStep ){
				isCurrent = true;
			}
			return <Question key={theQuestion.id} questionObj={theQuestion} isCurrent={isCurrent} />
		});

		return (
			<div className="App">
				{questionsOutput}
				<button onClick={this.switchStepNext}>Next</button>
			</div>
		);
	}


}

export default App;
