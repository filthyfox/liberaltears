import React, { Component } from 'react';

class Option extends Component {

    // constructor(props){
    //     super(props);
    //     state = {

    //     }
    // }

    render() {

        const {optionText, optionScore} = this.props;

        return (
            <div className="step-option">
                <label>
                    <input type="radio" name={"option-" + this.props.questionId} />
                    { optionText } — { optionScore }
                </label>
            </div>
        );
    }

}


export default Option;
